//Program: LocationApp
//This: location.java
//Date: 11/30/2015
//Author: Jason Welch
//Purpose: Class to find the Highest Value in a 2 dimensional Array

package locationapp;


public class Location 
{
    private int row;
    private int column;
    private double maxValue;
    
    // ============ Location default =================
    public Location()
    {
        
    }
    
    // ============ locateLargest =================
    public void locateLargest(double[][] twoDimArray)
    {
        // Clear Class Variables
        row = 0;
        column = 0;
        maxValue = twoDimArray[0][0];
        
        for(int arrayRow = 0; arrayRow < twoDimArray.length; arrayRow++)
        {
            for(int arrayColumn = 0; arrayColumn < twoDimArray[arrayRow].length; arrayColumn++)
            {
                if(twoDimArray[arrayRow][arrayColumn] > maxValue)
                {
                    row = arrayRow;
                    column = arrayColumn;
                    maxValue = twoDimArray[arrayRow][arrayColumn];
                }
                
            }
        }
    }
    
}
