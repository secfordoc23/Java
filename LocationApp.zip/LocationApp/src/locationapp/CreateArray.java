//Program: LocationApp
//This: createArray.java
//Date: 11/30/2015
//Author: Jason Welch
//Purpose: Class to create a 2 dimensional Array

package locationapp;

import java.util.Scanner;


public class CreateArray 
{
    // Class Variable Decalration
    int row;
    int column;
    private double[][] twoDimArray;
    
    //=========== CreateArray params ==========================
    public CreateArray(int row, int column)
    {
        this.row = row;
        this.column = column;
        
        this.twoDimArray = new double[row][column];
    }
    
    public double[][] fillArray()
    {        
        for(int index = 0; index < row; index++)
        {
            String[] numbers = getNumbers(index);
            if(validateNumbers(numbers) == false)
            {
                System.out.println("Please enter Numbers for all elements in the array!");
                index--;
            }
            else
            {
                updateArray(numbers, index);
            }
        }
        return twoDimArray;
    }
    
    //===========  validateNumbers ==========================
    private boolean validateNumbers(String[] numbers)
    {
        boolean isValid = true;
        
        String number;
        
        for(int index = 0; index < numbers.length; index++)
        {
            number = numbers[index];
            if(number.length() == 1)
            {
                if(Character.isDigit(number.charAt(0)) == false)
                {
                    isValid = false;
                }

            }
            else
            {
                for(int index2 = 0; index2 < number.length(); index2++)
                {
                    if(Character.isDigit(number.charAt(index2)) == false && number.charAt(index2) != '.')
                    {
                        isValid = false;
                    }
                }
            }
        }
        
        return isValid;
    }
    
    //===========  getNumbers ==========================
    private String[] getNumbers(int count)
    {
        String[] numArray = new String[this.column];
        
        // Keyboard input
        Scanner input = new Scanner(System.in);
        
        for(int index = 0; index < numArray.length; index++)
        {
            System.out.printf("Enter element %d for row %d: ", index, count);
            numArray[index] = input.next();
            
        }
        
        return numArray;
    }
    
    //===========  updateArray ==========================
    private void updateArray(String[] numbers, int row)
    {
        double[] array = new double[this.column];
        
        for(int index = 0; index < numbers.length; index++)
        {
            array[index] = Double.parseDouble(numbers[index]);
        }
        
        for(int index2 = 0; index2 < numbers.length; index2++)
        {
            twoDimArray[row][index2] = array[index2];
        }
    }
}
