//Program: LocationApp
//This: locationapp.java
//Date: 11/30/2015
//Author: Jason Welch
//Purpose: Test the location Class

package locationapp;

import java.util.Scanner;

public class LocationApp 
{
    private static double[][] twoDimArray;
    
    //===========  main ==========================
    public static void main(String[] args) 
    {
        // Call the Menu Method
        menu();
    }
    
    //============= menu ===================
    private static void menu()
    {
        // Variable Declaration
        boolean quit = false;
        char choice;
        
        String[] choices = {"Quit", "Test Location Class"};
        
        Menu myMenu = new Menu(choices);
        
        do
        {   

            choice = myMenu.getChoice(); 
            switch(choice)
            {
                case '0': quit = true;
                   break;
                case '1': 
                   optionOne();
                   break;
               
            }
        }while(quit == false);
    }
 
    //============= optionOne ===================
    private static void optionOne()
    {
        //Variable Declaration
        boolean validRow, validColumn;
        String row, column;
        
        //Keyboard input
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter Dimensions of a 2 dimensional array: ");        
        
        do
        {
            System.out.print("Enter row: ");
            row = input.next();
            validRow = validateNumber(row);
            
            //Clear line buffer
            System.out.println();
            
            System.out.print("Enter Columns: ");
            column = input.next();
            validColumn = validateNumber(column);
        } while(validRow == false || validColumn == false);
        
        CreateArray array = new CreateArray(Integer.parseInt(row), Integer.parseInt(column));
        
        twoDimArray = array.fillArray();
        
        Location test = new Location();
        
        test.locateLargest(twoDimArray);
        
    }

    //============= validateNumber ===================
    private static boolean validateNumber(String number)
    {
        

        if(number.length() == 1)
        {
            if(Character.isDigit(number.charAt(0)) == false)
            {
                System.out.println("Please Enter a Number!");
                return false;
            }

        }
        
        else
        {
            for(int index2 = 0; index2 < number.length(); index2++)
            {
                if(Character.isDigit(number.charAt(index2)) == false && number.charAt(index2) != '.')
                {
                    System.out.println("Please Enter a Number!");
                    return false;
                }
            }
        }
        
        return true;
    }    
}
